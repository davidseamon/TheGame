import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.*;

class TheGameToEndAllGames{
	
static int score = 0;
static int frameNum = 0;

 public static void main(String args[]) {
	 selectFrame();  
 }
 public static void makeFrame(String pic1, String pic2, Boolean hot) {
	 
	 //Create the frame
	 JFrame frame = new JFrame("main");
	 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	 frame.setSize(800,800);
	 
	 JPanel panel = new JPanel();
	 GridLayout layout = new GridLayout(2,2, 120, 120);
	 panel.setLayout(layout);
	 
	 //Create image 1
	 ImageIcon leftImage = new ImageIcon(pic1);
	 ImageIcon leftRealImage = new ImageIcon(leftImage.getImage().getScaledInstance(400, 400, 400));
	 JLabel leftLabel = new JLabel(leftRealImage);
	 leftLabel.setAlignmentX(100);
	 panel.add(leftLabel);
	 
	 
	 //Create image 2
	 ImageIcon rightImage = new ImageIcon(pic2);
	 ImageIcon rightRealImage = new ImageIcon(rightImage.getImage().getScaledInstance(400, 400, 400));
	 JLabel label = new JLabel(rightRealImage);
	 label.setAlignmentX(100);
	 panel.add(label);
	 
	 //Create the left button
	 JButton leftButton = new JButton("HOT");
	 leftButton.setSize(100,50);
	 leftButton.setFont(new Font("Impact", Font.BOLD, 40));
	 leftButton.setBackground(Color.red);
	 leftButton.addActionListener(new ActionListener() {
		@Override
		public void actionPerformed(ActionEvent e) {
			if (hot)	
				score = score + 1;
				//System.out.print(score);
				
				frame.dispose();
				frameNum++;
				selectFrame();
		}
		 
	 });
	 
	 panel.add(leftButton);
	 
	 //Create the right button
	 JButton rightButton = new JButton("NOT");
	 rightButton.setSize(100,50);
	 rightButton.setFont(new Font("Impact", Font.BOLD, 40));
	 rightButton.setBackground(Color.blue);
	 rightButton.addActionListener(new ActionListener() {
			@Override
			public void actionPerformed(ActionEvent e) {
				if (!hot)	
					score = score + 1;
					//System.out.print(score);
					frame.dispose();
					frameNum++;
					selectFrame();
			}
			 
		 });
	 panel.add(rightButton);
	 
	 frame.add(panel);
	 frame.setVisible(true);

 }
 
 public static void selectFrame() {
	
	 if (frameNum == 0) {
		 makeFrame("Donald1.jpg","Donald2.jpg",false);
	 }
	 else if (frameNum == 1) {
		 makeFrame("Jim1.jpg","Jim1.jpg",true);
	 }
	 else if (frameNum == 2) {
		 makeFrame("Patrick1.jpg","Patrick2.jpg",true);
	 }
	 else if (frameNum == 3) {
		 makeFrame("Ethan1.jpg","Ethan2.jpg",false);
	 }
	 else {
		 
		 System.out.println("You got " + score + "/4 right!");
	 }
	 
 } 
 
}